﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectronicMaps.Application.Project
{
    public class ProjectSaveService : IProjectSaveService
    {
        public Task<bool> SaveCurrentProjectAsync(CancellationToken ct = default)
        {
            throw new NotImplementedException();
        }

        public Task<bool> SaveProjectAsAsync(CancellationToken ct = default)
        {
            throw new NotImplementedException();
        }
    }
}
