﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectronicMaps.Domain.Enums
{
    public enum ComponentKind
    {
        Resistor = 1,
        Chip = 2,
    }
}
